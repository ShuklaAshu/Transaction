package com.transaction.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.transaction.demo.controller.dto.BookingFormDto;
import com.transaction.demo.service.BookTicketService;

@RequestMapping("book")

@RestController
public class BookTicketController {
	
	@Autowired
	private BookTicketService bookTicketService;
	
	@PostMapping("/")
	public String bookTicket(@RequestBody BookingFormDto bookingFormDto) {
		return bookTicketService.bookTicket(bookingFormDto);
	}

}