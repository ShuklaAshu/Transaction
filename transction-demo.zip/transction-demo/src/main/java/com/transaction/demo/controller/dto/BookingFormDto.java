package com.transaction.demo.controller.dto;

public class BookingFormDto {
	private String Name;
	private String Mobile;
	private int Age;
	private int seats;
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getMobile() {
		return Mobile;
	}
	public void setMobile(String mobile) {
		Mobile = mobile;
	}
	public int getAge() {
		return Age;
	}
	public void setAge(int age) {
		Age = age;
	}
	public int getSeats() {
		return seats;
	}
	public void setSeats(int seats) {
		this.seats = seats;
	}
	public BookingFormDto(String name, String mobile, int age, int seats) {
		super();
		Name = name;
		Mobile = mobile;
		Age = age;
		this.seats = seats;
	}
	public BookingFormDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	

}
