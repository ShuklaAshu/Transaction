package com.transaction.demo.service;

import org.springframework.stereotype.Service;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.RequestBody;

import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.databind.ObjectMapper;

import com.transaction.demo.controller.dto.BookingFormDto;
import com.transaction.demo.enitity.Booking;
import com.transaction.demo.enitity.Passenger;
import com.transaction.demo.repo.BookingRepo;
import com.transaction.demo.repo.PassengerRepo;

@Service
@Transactional
public class BookTicketService {

	@Autowired
	private BookingRepo bookingRepo;

	@Autowired
	private PassengerRepo passengerRepo;

	public String bookTicket(BookingFormDto bookingFormDto) {

		Passenger passenger = new ObjectMapper().convertValue(bookingFormDto, Passenger.class);

		Long passengerNumber = passengerRepo.save(passenger).getPassengerNumber();

		System.out.println("Booking saved successfully.");

		Booking booking = new Booking(new Date(System.currentTimeMillis()), 101L, passengerNumber);

		Long TicketBookingNumber = bookingRepo.save(booking).getTicketBookingNumber();

		return "TicketConfirmed."+ TicketBookingNumber;
	
	}
}