package com.transaction.demo.enitity;



import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Booking {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long TicketBookingNumber;
	private Date date;
	private Long TrainNumber;
	private Long passengerNumber;
	public Long getTicketBookingNumber() {
		return TicketBookingNumber;
	}
	
	
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public Long getTrainNumber() {
		return TrainNumber;
	}
	public void setTrainNumber(Long trainNumber) {
		TrainNumber = trainNumber;
	}
	public Long getPassengerNumber() {
		return passengerNumber;
	}
	public void setPassengerNumber(Long passengerNumber) {
		this.passengerNumber = passengerNumber;
	}
	public Booking(Date date, Long trainNumber, Long passengerNumber) {
		super();
		
		this.date = date;
		TrainNumber = trainNumber;
		this.passengerNumber = passengerNumber;
	}

	
	}