package com.transaction.demo.enitity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Passenger {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long passengerNumber;
	private String Name;
	private String Mobile;
	private int Age;
	private int seats;
	public Long getPassengerNumber() {
		return passengerNumber;
	}
	public void setPassengerNumber(Long passengerNumber) {
		this.passengerNumber = passengerNumber;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getMobile() {
		return Mobile;
	}
	public void setMobile(String mobile) {
		Mobile = mobile;
	}
	public int getAge() {
		return Age;
	}
	public void setAge(int age) {
		Age = age;
	}
	public int getSeats() {
		return seats;
	}
	public void setSeats(int seats) {
		this.seats = seats;
	}
	public Passenger(Long passengerNumber, String name, String mobile, int age, int seats) {
		super();
		this.passengerNumber = passengerNumber;
		Name = name;
		Mobile = mobile;
		Age = age;
		this.seats = seats;
	}
	
}
